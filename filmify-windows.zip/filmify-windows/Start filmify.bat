@echo off
rem Start filmify -- double-click me.
cd /d "%~dp0app-files"
call "START-HERE-WINDOWS.bat" --quiet
