#!/bin/bash
# Start filmify -- double-click me.
cd "$(dirname "$0")/app-files" || exit 1
exec /bin/bash ./filmify-launch.sh
